# Skinly V1 — GitHub Actions Build Package

This is the first Android prototype of Skinly. It is designed so the APK can be built on GitHub Actions without a PC.

## What is included
- Soft Pink prototype UI
- Onboarding/profile fields
- Home, Scan, Routine, Journal, Profile screens
- TEST MODE enabled for testing
- Local profile storage
- GitHub Actions workflow for a debug APK

## Important
This is a prototype, not a medical diagnostic app. Camera analysis, AI analysis, product matching, and the full skincare safety knowledge base are not implemented yet.

## Build from GitHub (phone-friendly)
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository, preserving `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build Skinly APK**.
5. Select **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the **Skinly-debug-apk** artifact.
8. Extract the artifact and install `app-debug.apk` on an Android test device.

If GitHub's mobile upload UI makes it difficult to upload the `.github/workflows` folder, create the workflow file manually in GitHub at `.github/workflows/build-apk.yml` and paste the contents from that file.

## Build details
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (provided by GitHub Actions)
- Java: 17
- compileSdk/targetSdk: 35
- minSdk: 23
- applicationId: `com.skinly.app`

## Development roadmap
1. Camera + image quality gate
2. Observable skin-analysis layer
3. Ingredient knowledge base + safety rules
4. Combination checker
5. AI explanation layer
6. Product finder
7. Privacy/data controls
8. Production signing and Play Store release
