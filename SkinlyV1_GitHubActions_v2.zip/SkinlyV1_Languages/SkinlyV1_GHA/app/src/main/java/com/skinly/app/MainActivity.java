package com.skinly.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int PINK=Color.rgb(233,143,176), DARK=Color.rgb(184,92,130), CREAM=Color.rgb(255,248,251), TEXT=Color.rgb(51,38,44), MUTED=Color.rgb(120,106,112), WHITE=Color.WHITE;
    LinearLayout root, content;
    SharedPreferences prefs;
    int step=0;
    String nickname="", lang="id";

    String t(String id, String en, String ms){ return lang.equals("en") ? en : lang.equals("ms") ? ms : id; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("skinly",MODE_PRIVATE);
        nickname=prefs.getString("nickname","");
        lang=prefs.getString("language","");
        if(lang.isEmpty()) showLanguagePicker();
        else if(prefs.getBoolean("onboarding_done",false)) showApp("Home");
        else showOnboarding();
    }

    TextView tv(String s,float size,int color){ TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setPadding(0,8,0,8); return v; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(15); b.setAllCaps(false); b.setBackgroundColor(DARK); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58); p.setMargins(0,12,0,0); b.setLayoutParams(p); return b; }
    Button choiceButton(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false); b.setTextColor(TEXT); b.setBackgroundColor(WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,60); p.setMargins(0,7,0,0); b.setLayoutParams(p); return b; }
    void base(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(CREAM); root.setPadding(24,20,24,18); setContentView(root); }

    void showLanguagePicker(){
        base();
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(box,new LinearLayout.LayoutParams(-1,0,1));
        Space top=new Space(this); box.addView(top,new LinearLayout.LayoutParams(1,55));
        TextView logo=tv("SKINLY 🌸",30,DARK); logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(logo);
        box.addView(tv("Choose your language\nPilih bahasa\nPilih bahasa anda",18,MUTED));
        addLanguage(box,"🇮🇩  Bahasa Indonesia","id");
        addLanguage(box,"🇬🇧  English","en");
        addLanguage(box,"🇲🇾  Bahasa Melayu","ms");
        box.addView(tv("You can change this later in Profile → Settings.",13,MUTED));
    }
    void addLanguage(LinearLayout box,String label,String code){ Button b=choiceButton(label); b.setOnClickListener(v->{lang=code; prefs.edit().putString("language",lang).apply(); showOnboarding();}); box.addView(b); }

    void showOnboarding(){
        base();
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=tv("SKINLY",22,DARK); logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD); top.addView(logo,new LinearLayout.LayoutParams(0,60,1));
        TextView prog=tv((step+1)+" / 9",13,MUTED); top.addView(prog); root.addView(top);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        renderStep();
    }

    void renderStep(){
        content.removeAllViews();
        if(step==0){
            content.addView(tv(t("Selamat datang di Skinly 🌸","Welcome to Skinly 🌸","Selamat datang ke Skinly 🌸"),28,TEXT));
            content.addView(tv(t("Panduan skincare yang dipersonalisasi, dibuat sederhana.\nTanpa beauty filter. Tanpa skor kulit palsu. Fokus pada panduan yang berguna.","Personalized skincare guidance made simple.\nNo beauty filter. No fake skin scores. Just useful guidance.","Panduan penjagaan kulit yang diperibadikan, dibuat ringkas.\nTanpa beauty filter. Tanpa skor kulit palsu."),17,MUTED));
            Button b=btn(t("Mulai","Start setup","Mula")); b.setOnClickListener(v->{step=1;renderStep();}); content.addView(b);
        } else if(step==1){
            content.addView(tv(t("Sebelum mulai, siapa nama panggilanmu?","Before we start, what should Skinly call you?","Sebelum mula, apakah nama panggilan anda?"),22,TEXT));
            EditText e=new EditText(this); e.setHint(t("Nama panggilan","Your nickname","Nama panggilan")); e.setText(nickname); content.addView(e);
            Button b=btn(t("Lanjut","Continue","Teruskan")); b.setOnClickListener(v->{nickname=e.getText().toString().trim(); if(nickname.isEmpty()) nickname=t("Teman","there","anda"); prefs.edit().putString("nickname",nickname).apply(); step=2;renderStep();}); content.addView(b);
        } else if(step==2){
            content.addView(tv(t("Berapa usiamu?","How old are you?","Berapa umur anda?"),22,TEXT));
            content.addView(tv(t("Usia membantu menyesuaikan konteks rekomendasi, bukan menentukan kondisi kulit sendirian.","Age helps provide context for recommendations; it does not determine your skin condition by itself.","Umur membantu memberi konteks untuk cadangan, bukan menentukan keadaan kulit dengan sendiri."),15,MUTED));
            EditText e=new EditText(this); e.setInputType(2); e.setHint(t("Usia","Age","Umur")); e.setText(prefs.getString("age","")); content.addView(e);
            Button b=btn(t("Lanjut","Continue","Teruskan")); b.setOnClickListener(v->{prefs.edit().putString("age",e.getText().toString().trim()).apply(); step=3;renderStep();}); content.addView(b);
        } else if(step==3){
            content.addView(tv(t("Bagaimana kecenderungan kulitmu sehari-hari?","How is your skin usually?","Bagaimanakah keadaan kulit anda biasanya?"),22,TEXT));
            String[] a={t("Cenderung kering","Usually dry","Cenderung kering"),t("Cenderung berminyak","Usually oily","Cenderung berminyak"),t("Kombinasi","Combination","Kombinasi"),t("Normal / seimbang","Normal / balanced","Normal / seimbang"),t("Tidak yakin","Not sure","Tidak pasti")};
            for(String x:a) addChoice(x,"skin");
        } else if(step==4){
            content.addView(tv(t("Apa yang paling sering kamu perhatikan pada kulitmu?","What do you notice most about your skin?","Apakah yang paling kerap anda perhatikan pada kulit?"),22,TEXT));
            content.addView(tv(t("Pilih maksimal 3","Choose up to 3","Pilih sehingga 3"),14,MUTED));
            String[] a={t("Kering / terasa ketarik","Dry / tight feeling","Kering / terasa tegang"),t("Berminyak","Oily","Berminyak"),t("Tekstur tidak merata","Uneven texture","Tekstur tidak sekata"),t("Kemerahan","Redness","Kemerahan"),t("Warna kurang merata","Uneven-looking tone","Warna kelihatan tidak sekata"),t("Bintik / benjolan kecil","Small bumps","Bintik / benjolan kecil"),t("Jerawat","Pimples","Jerawat"),t("Mengelupas","Peeling","Mengelupas"),t("Tidak nyaman setelah produk","Uncomfortable after products","Tidak selesa selepas produk"),t("Tidak yakin","Not sure","Tidak pasti"),t("Tidak ada keluhan khusus","No specific concern","Tiada masalah khusus")};
            for(String x:a)addCheck(x);
            Button b=btn(t("Lanjut","Continue","Teruskan")); b.setOnClickListener(v->{step=5;renderStep();}); content.addView(b);
        } else if(step==5){
            content.addView(tv(t("Bagaimana reaksi kulitmu terhadap skincare?","How does your skin react to skincare?","Bagaimanakah kulit anda bertindak balas terhadap skincare?"),22,TEXT));
            String[] a={t("Jarang bermasalah","Rarely reacts","Jarang bermasalah"),t("Kadang sensitif","Sometimes sensitive","Kadang sensitif"),t("Mudah sensitif","Easily sensitive","Mudah sensitif"),t("Sangat sensitif","Very sensitive","Sangat sensitif"),t("Tidak yakin","Not sure","Tidak pasti")};
            for(String x:a)addChoice(x,"sens");
        } else if(step==6){
            content.addView(tv(t("Apa tujuan utama skincare kamu?","What are your main skincare goals?","Apakah tujuan utama skincare anda?"),22,TEXT));
            content.addView(tv(t("Pilih maksimal 2","Choose up to 2","Pilih sehingga 2"),14,MUTED));
            String[] a={t("Menjaga kelembapan","Maintain hydration","Mengekalkan kelembapan"),t("Menjaga skin barrier","Support skin barrier","Menyokong skin barrier"),t("Kulit terlihat lebih sehat & merata","Healthier-looking, even-looking skin","Kulit kelihatan lebih sihat & sekata"),t("Mengurangi tampilan minyak","Reduce oily appearance","Kurangkan rupa berminyak"),t("Mengurangi munculnya jerawat / bintik","Reduce pimples / bumps","Kurangkan jerawat / bintik"),t("Memperbaiki tampilan tekstur","Improve texture appearance","Baiki rupa tekstur"),t("Melindungi dari matahari","Protect from sun exposure","Lindungi daripada matahari"),t("Menjaga kondisi kulit secara umum","Maintain overall skin condition","Jaga keadaan kulit secara umum"),t("Belum tahu","Not sure yet","Belum pasti")};
            for(String x:a)addCheck(x);
            Button b=btn(t("Lanjut","Continue","Teruskan")); b.setOnClickListener(v->{step=7;renderStep();}); content.addView(b);
        } else if(step==7){
            content.addView(tv(t("Berapa budget yang nyaman untuk skincare?","What budget feels comfortable for skincare?","Apakah bajet yang selesa untuk skincare?"),22,TEXT));
            content.addView(tv(t("Ini hanya memengaruhi saran produk, bukan analisis kulitmu.","This only affects product suggestions, not your skin analysis.","Ini hanya mempengaruhi cadangan produk, bukan analisis kulit."),15,MUTED));
            String[] a={"💰 "+t("Hemat","Affordable","Jimat"),"💰💰 "+t("Menengah","Mid-range","Sederhana"),"💰💰💰 "+t("Premium","Premium","Premium"),t("Belum menentukan","Not decided","Belum menentukan")};
            for(String x:a)addChoice(x,"budget");
        } else {
            content.addView(tv(t("Siap untuk skin scan","Ready for your skin scan","Sedia untuk skin scan"),22,TEXT));
            content.addView(tv(t("Gunakan kamera biasa dengan pencahayaan merata. Tidak ada beauty filter, smoothing, whitening, atau face reshaping.\n\nDi V1 ini, kamera dan AI analysis masih tahap berikutnya.","Use a normal camera with even lighting. No beauty filter, smoothing, whitening, or face reshaping.\n\nIn V1, camera and AI analysis are the next build phase.","Gunakan kamera biasa dengan pencahayaan sekata. Tiada beauty filter, smoothing, whitening atau ubah bentuk muka.\n\nDalam V1, kamera dan analisis AI akan disambungkan pada fasa seterusnya."),16,MUTED));
            Button b=btn(t("Selesai & masuk ke Skinly","Finish setup","Selesai & masuk Skinly")); b.setOnClickListener(v->{prefs.edit().putBoolean("onboarding_done",true).apply(); showApp("Home");}); content.addView(b);
            Button l=choiceButton(t("Ganti bahasa","Change language","Tukar bahasa")); l.setOnClickListener(v->showLanguagePicker()); content.addView(l);
        }
    }

    void addChoice(String label,String key){ Button b=choiceButton(label); b.setOnClickListener(v->{prefs.edit().putString(key,label).apply(); if(step==3||step==5||step==7){step++;renderStep();}}); content.addView(b); }
    void addCheck(String label){ CheckBox c=new CheckBox(this); c.setText(label); c.setTextSize(15); c.setTextColor(TEXT); content.addView(c); }

    void showApp(String page){
        base();
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        showPage(page); nav();
    }

    void showPage(String page){
        content.removeAllViews();
        String greeting=t("Selamat datang, ","Good afternoon, ","Selamat datang, ")+nickname+" ✨";
        TextView h=tv(greeting,25,TEXT); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); content.addView(h);
        if(page.equals("Home")){
            card("🧴 "+t("Rutinitas Hari Ini","Today's Routine","Rutin Hari Ini"),t("Pagi + Malam\nTetap sederhana. Tetap konsisten.","Morning + Night\nKeep it simple. Stay consistent.","Pagi + Malam\nKekalkan ringkas. Kekalkan konsisten."));
            card("📷 "+t("Profil Kulit","Skin Profile","Profil Kulit"),t("Profil scan akan muncul setelah analisis tersedia.","Your scan profile will appear after analysis is available.","Profil scan akan muncul selepas analisis tersedia."));
            card("🌿 "+t("Kebiasaan Sehat","Healthy Habits","Tabiat Sihat"),t("Tidur • perlindungan matahari • hidrasi • hindari menyentuh wajah tanpa perlu","Sleep • sun protection • hydration • avoid unnecessary face touching","Tidur • perlindungan matahari • hidrasi • elak sentuh muka tanpa perlu"));
        } else if(page.equals("Scan")){
            content.addView(tv(t("Skin Scan","Skin Scan","Skin Scan"),28,TEXT));
            content.addView(tv(t("Kamera biasa • tanpa beauty filter • tanpa whitening • tanpa face reshaping\n\nV1: kamera + quality gate akan disambungkan pada tahap berikutnya.","Normal camera • no beauty filter • no whitening • no face reshaping\n\nV1: camera + quality gate will be connected in the next phase.","Kamera biasa • tanpa beauty filter • tanpa whitening • tanpa ubah bentuk muka\n\nV1: kamera + quality gate akan disambungkan pada fasa seterusnya."),16,MUTED));
            Button b=btn(t("Mulai Skin Scan","Start Skin Scan","Mula Skin Scan")); b.setOnClickListener(v->Toast.makeText(this,t("Kamera AI belum tersambung di V1.","AI camera analysis is not connected in V1 yet.","Analisis kamera AI belum disambungkan dalam V1."),Toast.LENGTH_SHORT).show()); content.addView(b);
        } else if(page.equals("Routine")){
            content.addView(tv(t("Rutinitas Kamu","Your Routine","Rutin Anda"),28,TEXT));
            card("☀️ "+t("Pagi","Morning","Pagi"),"□ "+t("Cleanser","Cleanser","Pencuci muka")+"\n□ "+t("Moisturizer","Moisturizer","Pelembap")+"\n□ "+t("Sunscreen","Sunscreen","Sunscreen"));
            card("🌙 "+t("Malam","Night","Malam"),"□ "+t("Cleanser","Cleanser","Pencuci muka")+"\n□ "+t("Moisturizer","Moisturizer","Pelembap")+"\n□ "+t("Treatment opsional","Optional treatment","Rawatan pilihan"));
        } else if(page.equals("Journal")){
            content.addView(tv(t("Jurnal Kulit","Skin Journal","Jurnal Kulit"),28,TEXT));
            content.addView(tv(t("Bagaimana kondisi kulitmu hari ini?","How has your skin been feeling today?","Bagaimanakah keadaan kulit anda hari ini?"),16,MUTED));
            for(String x:new String[]{t("Nyaman","Comfortable","Selesa"),t("Normal","Normal","Normal"),t("Kering","Dry","Kering"),t("Berminyak","Oily","Berminyak"),t("Iritasi","Irritated","Teriritasi"),t("Sensitif","Sensitive","Sensitif"),t("Tidak yakin","Not sure","Tidak pasti")}){ Button b=choiceButton(x); b.setOnClickListener(v->Toast.makeText(this,t("Dicatat di jurnal.","Saved to journal.","Disimpan dalam jurnal."),Toast.LENGTH_SHORT).show()); content.addView(b); }
        } else {
            content.addView(tv(t("Profil","Profile","Profil"),28,TEXT));
            card("👤 "+t("Profil kamu","Your profile","Profil anda"),t("Nama: ","Name: ","Nama: ")+nickname+"\n"+t("Usia: ","Age: ","Umur: ")+prefs.getString("age","")+"\nTEST MODE: ON");
            Button langBtn=choiceButton("🌐 "+t("Bahasa: Indonesia","Language: English","Bahasa: Melayu")); langBtn.setOnClickListener(v->showLanguagePicker()); content.addView(langBtn);
            card("🔒 "+t("Pusat Privasi","Privacy Center","Pusat Privasi"),t("Kelola riwayat scan, jurnal, dan data aplikasi.","Manage scan history, journal data, and app data.","Urus sejarah scan, jurnal, dan data aplikasi."));
            card("⚙️ "+t("Pengaturan","Settings","Tetapan"),t("Tampilan • notifikasi • rutinitas • privasi • tentang","Appearance • notifications • routine • privacy • about","Paparan • notifikasi • rutin • privasi • tentang"));
        }
    }

    void card(String title,String body){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(18,15,18,15); c.setBackgroundColor(WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,10,0,10); c.setLayoutParams(p); TextView a=tv(title,18,DARK); a.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(a); c.addView(tv(body,15,MUTED)); content.addView(c); }

    void nav(){
        LinearLayout n=new LinearLayout(this); n.setGravity(Gravity.CENTER); String[] names={"Home","Scan","Routine","Journal","Profile"};
        for(String x:names){ String label=x; Button b=new Button(this); b.setText(x.equals("Home")?t("Beranda","Home","Utama"):x.equals("Scan")?"Scan":x.equals("Routine")?t("Rutinitas","Routine","Rutin"):x.equals("Journal")?t("Jurnal","Journal","Jurnal"):t("Profil","Profile","Profil")); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(TEXT); b.setBackgroundColor(CREAM); b.setOnClickListener(v->showPage(label)); n.addView(b,new LinearLayout.LayoutParams(0,58,1)); }
        root.addView(n);
    }
}
